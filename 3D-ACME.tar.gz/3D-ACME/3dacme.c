/*
 * 3dsst.c
 *
 *  Created on: Mar 12, 2012
 *      Author: qian
 */

#include <stdio.h>
#include <stdlib.h>
#include <assert.h>
#include <string.h>
#include <ctype.h>
#include <math.h>
#include <time.h>
#include <sys/time.h>

#include "auxiliary.h"
#include "stack.h"
#include "thermal.h"

int main(int argc, char **argv)
{
	/*check legacy of input variables*/
	if((argc<3||argc>7)&&argc%2)
	{
		usage(argc, argv);
		return 0;
	}

	int size;
	str_pair table[MAX_Entry];
	size=parse_cmdline(table, argc, argv);

	IO_t IO;
	fill_IO_opt(&IO, table, (argc-1)/2);

	stk_descr_t stk;
	build_stack_description(&IO, &stk);

	printf("stk built\n");

	thermal_data_t *thermo;
	thermo=init_thermal_data(&stk);

	fill_thermal_data(&stk, thermo);

	solve_steady_state(&stk, thermo);

	dump_tmap(&IO, &stk, thermo, "./results/example.tmap");
	printf("result dumped\n");

	clean_thermal_data(&stk, thermo);
	printf("thermo cleaned\n");
	clean_stk_description(&stk);

	printf("=========== End of Simulation ============\n");

	return 0;

}
