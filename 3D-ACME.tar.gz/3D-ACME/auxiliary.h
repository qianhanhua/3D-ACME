/*
 * auxiliary.h
 *
 *  Created on: Mar 12, 2012
 *      Author: qian
 */

#include <stdio.h>
#include <stdlib.h>
#include <math.h>
#include <string.h>

#ifndef AUXILIARY_H_
#define AUXILIARY_H_

#define STR_SIZE		512
#define MAX_Entry		512
#define LINE_SIZE		65536

/*layer configuration file constants*/

#define LCF_NPARAMS			2
//Digit line containing layer number, thickness of BEOL, SOURCE and BULK
#define LCF_DIGIT			0
//String line containing floorplan filename
#define LCF_STRING			1

#define	NumSubLayers		3

#define DELTA			1.0e-6

#define MAX(x,y)		(((x)>(y))?(x):(y))
#define MIN(x,y)		(((x)<(y))?(x):(y))

typedef struct IO_option_st
{
	char 	lcf[512];
	char 	steady_temp[512];
	char 	thermal_map[512];

} IO_t;

/* a table of name value pairs	*/
typedef struct str_pair_st
{
	char name[512];
	char value[512];
}str_pair;

/*print out usage when cmd input not right*/
void usage(int argc, char **argv);

/*error handler*/
void fatal(char *s);

/*
 * the command line is of the form <prog_name> <name-value pairs> where
 * <name-value pairs> is of the form -<variable> <value>
 */

int parse_cmdline(str_pair *table, int argc, char **argv);

/* table lookup	for a name */
int get_str_index(str_pair *table, int size, char *str);

/*fill up the input output options*/
void fill_IO_opt(IO_t *IO_opt, str_pair *table, int size);

/*
 * reads tab-separated name-value pairs from file into
 * a table of size max_entries and returns the number
 * of entries read successfully
 */
int read_str_pairs(str_pair *table, int max_entries, char *file);

/*
 * find the number of non-empty, non-comment lines
 * in a file open for reading
 */
int count_significant_lines(FILE *fp);

/*compare two numbers if equal return 1*/
int eq(double x, double y);

int tolerant_ceil(double val);

int tolerant_floor(double val);

int double2int(double value);

void dump_sparse_matrix(int *Ap, int *Ai, double *Ax, int size, char *file);

/* get resistor value by conductivity, area and length
 * R = L / (k * A)
 */
double getr(double k, double l, double area);

#endif /* AUXILIARY_H_ */
